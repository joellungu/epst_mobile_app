import 'package:flutter/material.dart';

class Parcour extends StatelessWidget {
  double x, y;
  String classe;
  double pourcentage;
  Color couleur;
  Parcour(this.x, this.y, this.classe, this.pourcentage, this.couleur);
  //
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return InkWell(
      onTap: (){
        //
      },
      child: Padding(
        padding: EdgeInsets.all(2),
        child: Align(
          alignment: Alignment(x, y),
          child: Container(
            height: 70,
            width: 70,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: couleur,
              borderRadius: BorderRadius.circular(30),
            ),
            child: Stack(
              children: [
                Padding(
                  padding: EdgeInsets.all(0),
                  child: Align(
                    alignment: Alignment.center,
                    child: Text(classe,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(0),
                  child: pourcentage != 0 ? Align(
                    alignment: Alignment.bottomLeft,
                    child: Container(
                      height: 30,
                      width: 40,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Colors.green,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("$pourcentage %",
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ): Container(),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

}
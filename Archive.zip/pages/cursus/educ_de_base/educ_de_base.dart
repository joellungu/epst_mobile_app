import 'package:aya_hotel/widgets/evolution.dart';
import 'package:aya_hotel/widgets/evolution_widget.dart';
import 'package:aya_hotel/widgets/parcour.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class EducDeBase extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      height: Get.size.height / 1.3,
      width: Get.size.width,
      color: Colors.white,
      //.shade200.withOpacity(0.2),
      child: Stack(
        children: [
          Container(
            height: Get.size.height / 1.3,
            width: Get.size.width,
            alignment: Alignment.center,
            child: Text("EDUCATION DE BASE",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 75,
                fontWeight: FontWeight.bold,
                color: Colors.blue.shade100.withOpacity(0.2),
              ),
            ),
          ),
          //La pas
          EvolutionWidget(100, 100, 140, 0.2, 0.80),//Premier pas
          EvolutionWidget(200, 100, 10, -0.2, 0.85),//Deuxieme
          EvolutionWidget(130, 100, 155, -0.55, 0.25),//Troisieme
          EvolutionWidget(100, 100, 120, 0.4, -0.15),//Quatrieme
          EvolutionWidget(200, 100, 13, 0.15, -0.20),//Cienquieme
          EvolutionWidget(200, 100, 160, 0.15, -0.85),//Sizieme
          EvolutionWidget(100, 100, 20, 0.4, -0.75),
          //
          Parcour(0, 1, "1", 60, Colors.blue),
          Parcour(0.75, 0.70, "2", 0, Colors.blue),
          Parcour(-0.95, 0.5, "3", 0, Colors.blue),
          Parcour(0.3, 0.25, "4", 0, Colors.blue),
          Parcour(0.8, -0.25, "5", 0, Colors.blue),
          Parcour(-0.7, -0.5, "6", 0, Colors.blue),
          Parcour(0.95, -0.75, "7", 0, Colors.blue),
          Parcour(0, -1, "8", 0, Colors.blue),



        ],
      ),
    );
  }

}
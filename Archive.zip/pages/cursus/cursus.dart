import 'package:aya_hotel/pages/login/login_enseignant/login_enseignant.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

import 'educ_de_base/educ_de_base.dart';
import 'secondaire/secondaire.dart';

class Cursus extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //
    return Scaffold(
      body: ListView(
        reverse: true,

        children: [
          EducDeBase(),
          Container(
            height: 30,
            width: Get.size.width,
            color: Colors.teal.shade700,
            alignment: Alignment.center,
            child: Text("TENAFEPP", style: TextStyle(
              color: Colors.white
            ),),
          ),
          Secondaire(),
          Container(
            height: Get.size.height / 1.3,
            width: Get.size.width,
            color: Colors.green.shade200,
          ),

        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          showModalBottomSheet(
              context: context,
              barrierLabel: "Profil utilisateur",
              //barrierColor: Colors.black,
              showDragHandle: true,
              builder: (context){
                return Container(
                  width: Get.size.width,
                  padding: EdgeInsets.all(10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Expanded(
                        flex: 1,
                        child: Wrap(
                          children: [
                            InkWell(
                              onTap: (){
                                //
                                Get.back();
                              },
                              child: Container(
                                height: 65,
                                width: 130,
                                alignment: Alignment.center,
                                child: Column(
                                  children: [
                                    Container(
                                      height: 40,
                                      width: 40,
                                      decoration: BoxDecoration(
                                        color: Colors.blue.shade100.withOpacity(0.7),
                                          borderRadius: BorderRadius.circular(20)
                                      ),
                                    ),
                                    const SizedBox(height: 2,),
                                    const Align(
                                      alignment: Alignment.center,
                                      child: Text("Joel Lungu"),
                                    )
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                      const SizedBox(height: 5,),
                      ElevatedButton(
                        onPressed: (){
                          //
                          Get.back();
                          //
                          Get.dialog(
                             Center(
                               child: Card(
                                  child: Container(
                                  height: 170,
                                  width: Get.size.width / 1.5,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                                    children: [
                                      Align(
                                        alignment: Alignment.topCenter,
                                        child: Text("Nouveau profil",
                                          style: TextStyle(
                                            fontWeight: FontWeight.w900,
                                            fontSize: 15,
                                            color: Colors.grey.shade700,
                                          ),),
                                      ),
                                      ElevatedButton(
                                        onPressed: (){
                                          Get.back();
                                          Get.to(LoginEnseignant());
                                      },
                                      style: ButtonStyle(
                                        backgroundColor: WidgetStateProperty.all(Colors.blue),
                                        textStyle: WidgetStateProperty.all(
                                          TextStyle(
                                          color: Colors.white, fontSize: 13,
                                        ),
                                    ),
                                ),
                                      child: const Text("Enseignant",
                                          style: TextStyle(
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                      //
                                      ElevatedButton(
                                        onPressed: (){
                                          Get.back();
                                          //
                                        },
                                        style: ButtonStyle(
                                          backgroundColor: WidgetStateProperty.all(Colors.blue),
                                          textStyle: WidgetStateProperty.all(
                                            TextStyle(
                                              color: Colors.white, fontSize: 13,
                                            ),
                                          ),
                                        ),
                                        child: const Text("Elève",
                                          style: TextStyle(
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),

                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                        style: ButtonStyle(
                          backgroundColor: WidgetStateProperty.all(Colors.blue),
                          textStyle: WidgetStateProperty.all(TextStyle(
                            color: Colors.white, fontSize: 13,
                          ),
                          ),
                        ),
                        child: Text("Ajouter", style: TextStyle(
                          color: Colors.white,
                        ),
                        ),
                      )
                    ],
                  ),
                );
              }
          );
        },
        child: SvgPicture.asset(
          "assets/UiwUser.svg",
          semanticsLabel: 'Acme Logo',
          color: Colors.black,
        ),
      ),
    );
  }

}
